create definer = Insa5_SpringA_final_3@`%` trigger auto_grade_student_answer
    before insert
    on student_answers
    for each row
BEGIN
   DECLARE correct_ans VARCHAR(255);
   DECLARE question_type VARCHAR(50);
   DECLARE student_ans VARCHAR(255);
   DECLARE eng_ans VARCHAR(255);
   DECLARE kor_ans VARCHAR(255);
   DECLARE clean_correct_ans VARCHAR(255);
   DECLARE first_part VARCHAR(255);
   DECLARE second_part VARCHAR(255);
   DECLARE student_first_part VARCHAR(255);
   DECLARE student_second_part VARCHAR(255);
   DECLARE clean_correct_answer VARCHAR(10);
   DECLARE clean_student_answer VARCHAR(10);
   
   -- 특수 문자를 일반 문자로 변환하는 함수
   SET @str = NEW.student_answer;
   SET @str = REPLACE(@str, 'é', 'e');
   SET @str = REPLACE(@str, 'è', 'e');
   SET @str = REPLACE(@str, 'ê', 'e');
   SET @str = REPLACE(@str, 'ë', 'e');
   SET @str = REPLACE(@str, 'í', 'i');
   SET @str = REPLACE(@str, 'ì', 'i');
   SET @str = REPLACE(@str, 'î', 'i');
   SET @str = REPLACE(@str, 'ï', 'i');
   SET @str = REPLACE(@str, 'á', 'a');
   SET @str = REPLACE(@str, 'à', 'a');
   SET @str = REPLACE(@str, 'â', 'a');
   SET @str = REPLACE(@str, 'ä', 'a');
   SET @str = REPLACE(@str, 'ó', 'o');
   SET @str = REPLACE(@str, 'ò', 'o');
   SET @str = REPLACE(@str, 'ô', 'o');
   SET @str = REPLACE(@str, 'ö', 'o');
   SET @str = REPLACE(@str, 'ú', 'u');
   SET @str = REPLACE(@str, 'ù', 'u');
   SET @str = REPLACE(@str, 'û', 'u');
   SET @str = REPLACE(@str, 'ü', 'u');
   SET @str = REPLACE(@str, 'ñ', 'n');
   SET @str = REPLACE(@str, 'ý', 'y');
   
   -- 문제의 정답과 유형 가져오기
   SELECT correct_answer, question_format 
   INTO correct_ans, question_type
   FROM question
   WHERE idx = NEW.idx;
   
   -- 정답에서도 특수 문자 변환
   SET @correct_str = correct_ans;
   SET @correct_str = REPLACE(@correct_str, 'é', 'e');
   SET @correct_str = REPLACE(@correct_str, 'è', 'e');
   SET @correct_str = REPLACE(@correct_str, 'ê', 'e');
   SET @correct_str = REPLACE(@correct_str, 'ë', 'e');
   SET @correct_str = REPLACE(@correct_str, 'í', 'i');
   SET @correct_str = REPLACE(@correct_str, 'ì', 'i');
   SET @correct_str = REPLACE(@correct_str, 'î', 'i');
   SET @correct_str = REPLACE(@correct_str, 'ï', 'i');
   SET @correct_str = REPLACE(@correct_str, 'á', 'a');
   SET @correct_str = REPLACE(@correct_str, 'à', 'a');
   SET @correct_str = REPLACE(@correct_str, 'â', 'a');
   SET @correct_str = REPLACE(@correct_str, 'ä', 'a');
   SET @correct_str = REPLACE(@correct_str, 'ó', 'o');
   SET @correct_str = REPLACE(@correct_str, 'ò', 'o');
   SET @correct_str = REPLACE(@correct_str, 'ô', 'o');
   SET @correct_str = REPLACE(@correct_str, 'ö', 'o');
   SET @correct_str = REPLACE(@correct_str, 'ú', 'u');
   SET @correct_str = REPLACE(@correct_str, 'ù', 'u');
   SET @correct_str = REPLACE(@correct_str, 'û', 'u');
   SET @correct_str = REPLACE(@correct_str, 'ü', 'u');
   SET @correct_str = REPLACE(@correct_str, 'ñ', 'n');
   SET @correct_str = REPLACE(@correct_str, 'ý', 'y');
   
   -- 학생 답안 전처리 (따옴표 제거 및 공백 처리)
   SET student_ans = TRIM(REPLACE(REPLACE(REPLACE(@str, '"', ''), "'", ''), '`', ''));
   
   -- 정답 문자열에서 따옴표 제거 및 공백 처리
   IF LEFT(@correct_str, 1) = "'" AND RIGHT(@correct_str, 1) = "'" THEN
       SET clean_correct_ans = TRIM(SUBSTRING(@correct_str, 2, LENGTH(@correct_str) - 2));
   ELSE
       SET clean_correct_ans = TRIM(@correct_str);
   END IF;
   SET clean_correct_ans = TRIM(REPLACE(REPLACE(REPLACE(clean_correct_ans, '"', ''), "'", ''), '`', ''));
   
   -- 채점 로직
	IF question_type = 'multiple-choice' THEN
		-- 정답 전처리: 첫 번째 A-D 문자 추출
		IF clean_correct_ans REGEXP '[A-D]' THEN
			SET clean_correct_answer = SUBSTRING(clean_correct_ans, 
				REGEXP_INSTR(clean_correct_ans, '[A-D]'), 1);
		ELSE
			SET clean_correct_answer = clean_correct_ans;
		END IF;
		
		-- 학생 답안에서도 첫 번째 A-D 문자 추출
		IF student_ans REGEXP '[A-D]' THEN
			SET clean_student_answer = SUBSTRING(student_ans,
				REGEXP_INSTR(student_ans, '[A-D]'), 1);
		ELSE
			SET clean_student_answer = student_ans;
		END IF;
		
		-- 정제된 답안으로 비교
		IF UPPER(clean_student_answer) = UPPER(clean_correct_answer) THEN
			SET NEW.is_correct = 1;
			SET NEW.score = 10;
			SET NEW.feedback = '정답입니다!';
		ELSE
			SET NEW.is_correct = 0;
			SET NEW.score = 0;
			SET NEW.feedback = CONCAT('오답입니다. 정답은 ', UPPER(clean_correct_answer), ' 입니다.');
		END IF;
   ELSE
       -- 주관식 문제 처리
       -- 정답 파싱 - 영어(한글) 또는 한글(영어) 형식 모두 처리
       IF LOCATE('(', clean_correct_ans) > 0 THEN
           SET first_part = TRIM(SUBSTRING_INDEX(clean_correct_ans, '(', 1));
           SET second_part = TRIM(BOTH ')' FROM SUBSTRING_INDEX(clean_correct_ans, '(', -1));
           
           -- 첫 부분이 한글인지 확인
           IF first_part REGEXP '^[가-힣]+$' THEN
               SET kor_ans = first_part;
               SET eng_ans = second_part;
           ELSE
               SET eng_ans = first_part;
               SET kor_ans = second_part;
           END IF;
       ELSE
           -- 단일 답안인 경우 (한글 또는 영어)
           IF clean_correct_ans REGEXP '^[가-힣]+$' THEN
               SET kor_ans = clean_correct_ans;
               SET eng_ans = NULL;
           ELSE
               SET eng_ans = clean_correct_ans;
               SET kor_ans = NULL;
           END IF;
       END IF;
       
       -- 학생 답안 파싱
       IF LOCATE('(', student_ans) > 0 THEN
           SET student_first_part = TRIM(SUBSTRING_INDEX(student_ans, '(', 1));
           SET student_second_part = TRIM(BOTH ')' FROM SUBSTRING_INDEX(student_ans, '(', -1));
       END IF;
       
       -- 주관식 채점
       IF (eng_ans IS NOT NULL AND LOWER(student_ans) = LOWER(eng_ans)) -- 영어 정답과 비교
          OR (kor_ans IS NOT NULL AND student_ans = kor_ans) -- 한글 정답과 비교
          OR (student_first_part IS NOT NULL AND ( -- 학생이 괄호 형식으로 답한 경우
              (LOWER(student_first_part) = LOWER(eng_ans) AND student_second_part = kor_ans) OR
              (student_first_part = kor_ans AND LOWER(student_second_part) = LOWER(eng_ans))
          ))
          OR LOWER(student_ans) = LOWER(clean_correct_ans) -- 전체 정답과 직접 비교
       THEN
           SET NEW.is_correct = 1;
           SET NEW.score = 10;
           SET NEW.feedback = '정답입니다!';
       ELSE
           SET NEW.is_correct = 0;
           SET NEW.score = 0;
           IF kor_ans IS NOT NULL AND eng_ans IS NOT NULL THEN
               -- 영어(한글) 형식으로 피드백 제공
               SET NEW.feedback = CONCAT('오답입니다. 정답은 ', eng_ans, '(', kor_ans, ') 입니다.');
           ELSE
               SET NEW.feedback = CONCAT('오답입니다. 정답은 ', clean_correct_ans, ' 입니다.');
           END IF;
       END IF;
   END IF;
END;

